"use strict";
cc._RFpush(module, '09108IJqFRJ7qW9YWpDFb5J', 'SpriteDown');
// SpriteDown.js

cc.Class({
    'extends': cc.Component,

    properties: {
        speed: 0,
        type: 0,
        touchAudio: {
            'default': null,
            url: cc.AudioClip
        },
        endAudio: {
            'default': null,
            url: cc.AudioClip
        }
    },

    // use this for initialization
    onLoad: function onLoad() {
        this.isinstate = false;
        this.stateMaxindex = 0;
        this.stateindex = 0;
        this.dir = 2;

        this.size = cc.director.getWinSize();
        this.anim = this.getComponent(cc.Animation);
        // this.anim.play("zb1die");
        this.isdie = false;
        this.setInputControl();
    },
    // called every frame, uncomment this function to activate update callback
    update: function update(dt) {

        if (!this.isdie) {
            if (this.type == 3) {
                if (this.node.y + 50 > 300) {
                    this.getComponent(cc.Sprite).setVisible(false);
                } else if (this.node.y <= 300 || this.node.y <= 0) {
                    this.getComponent(cc.Sprite).setVisible(true);
                }
                this.node.y -= this.speed;
                //随机一个反向，随即一个时间，20帧随机一次，3个状态
                if (!this.isinstate) {
                    this.isinstate = true;
                    //随机方向
                    this.dir = parseInt(cc.random0To1() * 3);
                    this.stateMaxindex = parseInt(cc.random0To1() * 20 + 20);
                    this.stateindex = 0;
                }
                if (this.dir == 0) {
                    if (this.node.x - 2 < -this.size.width / 2 + 20) {
                        this.dir = 1;
                    } else {
                        this.node.x -= 2;
                    }
                } else if (this.dir == 1) {
                    if (this.node.x + 2 > this.size.width / 2 - 20) {
                        this.dir = 0;
                    } else {
                        this.node.x += 2;
                    }
                }
                this.stateindex++;
                if (this.stateindex > this.stateMaxindex) {
                    this.isinstate = false;
                }
            } else if (this.type == 2) {
                this.node.y -= this.speed;
            } else if (this.type == 0) {
                this.node.y -= this.speed;
            } else if (this.type == 1) {
                this.node.y -= this.speed;

                //随机一个反向，随即一个时间，20帧随机一次，3个状态
                if (!this.isinstate) {
                    this.isinstate = true;
                    //随机方向
                    this.dir = parseInt(cc.random0To1() * 3);
                    this.stateMaxindex = parseInt(cc.random0To1() * 20 + 20);
                    this.stateindex = 0;
                }
                if (this.dir == 0) {
                    if (this.node.x - 2 < -this.size.width / 2 + 20) {
                        this.dir = 1;
                    } else {
                        this.node.x -= 2;
                    }
                } else if (this.dir == 1) {
                    if (this.node.x + 2 > this.size.width / 2 - 20) {
                        this.dir = 0;
                    } else {
                        this.node.x += 2;
                    }
                }
                this.stateindex++;
                if (this.stateindex > this.stateMaxindex) {
                    this.isinstate = false;
                }
            }
            if (this.type == 2) {
                return;
            } else if (this.node.y < -this.size.height / 2 - 20) {
                cc.audioEngine.playEffect(this.endAudio, false);
                this.node.destroy();
                cc.director.pause();
                //this.node.parent.getComponent('GameManager').spawnZombie(0);
                this.node.parent.getComponent('GameManager').goEnd();
            }
        }
    },
    setInputControl: function setInputControl() {
        var self = this;

        cc.eventManager.addListener({
            event: cc.EventListener.TOUCH_ONE_BY_ONE,
            onTouchBegan: self._onTouchBegan.bind(self)
        }, self);
    },
    _onTouchBegan: function _onTouchBegan(touch, event) {
        var tpos = this.node.convertTouchToNodeSpace(touch);
        if (!cc.director.isPaused() && !this.isdie && cc.pDistance(cc.p(this.node.width / 2, this.node.height / 2), tpos) < 20) {
            this.godie();
            cc.audioEngine.playEffect(this.touchAudio, false);
            this.isdie = true;

            this.schedule(function () {
                if (this.type == 2) {
                    cc.audioEngine.playEffect(this.endAudio, false);
                    cc.director.pause();
                    this.node.destroy();
                    this.node.parent.getComponent('GameManager').goEnd();
                } else {
                    this.node.destroy();
                    this.node.parent.getComponent('GameManager').gainScore();
                }
            }, 1, 0.5, 0.5);
        }
        return true;
    },
    godie: function godie() {
        if (this.type == 0) {
            this.anim.play("Die");
        } else if (this.type == 1) {
            this.anim.play("TwoDie");
        } else if (this.type == 2) {
            this.anim.play("childDie");
        } else if (this.type == 3) {
            this.anim.play("action3Die");
        }
    }

});

cc._RFpop();