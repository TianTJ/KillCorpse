cc.Class({
    'extends': cc.Component,

    properties: {
        //僵尸数组
        zbslist: {
            'default': [],
            type: [cc.Prefab]
        },
        //背景图片
        bglist: {
            'default': [],
            type: [cc.SpriteFrame]
        },
        //背景对象
        bg: {
            'default': null,
            type: cc.Sprite
        },
        gameover: {
            'default': null,
            type: cc.Node
        },
        bgAudio: {
            'default': null,
            url: cc.AudioClip
        },
        // score label 的引用
        scoreDisplay: {
            'default': null,
            type: cc.Label
        },
        // // score label 的引用
        scoreDisplay2: {
            'default': null,
            type: cc.Label
        }
    },

    // use this for initialization
    onLoad: function onLoad() {
        //随机背景
        var bgid = parseInt(cc.random0To1() * 3);
        cc.log("随机到的背景：%d", bgid);
        this.bg.spriteFrame = this.bglist[bgid];
        //定义怪物数组
        // this.zombies = [];

        this.gameover.active = false;
        this.timeindex = 0;
        this.score = 0;
        //声音
        cc.audioEngine.playEffect(this.bgAudio, true);
    },
    spawnZombie: function spawnZombie(type) {
        // 使用给定的模板在场景中生成一个新节点
        var newZombie = cc.instantiate(this.zbslist[type]);
        // 将新增的节点添加到 Canvas 节点下面
        this.node.addChild(newZombie);
        // newZombie.getComponent('Zombie').init(type);
        // 为星星设置一个随机位置
        newZombie.setPosition(this.getNewZombiePosition());
    },
    gainScore: function gainScore() {
        this.score += 1;

        //   // 更新 scoreDisplay Label 的文字
        this.scoreDisplay.string = 'Score:' + this.score.toString();
        this.scoreDisplay2.string = '' + this.score.toString();
    },

    getNewZombiePosition: function getZombiePosition() {

        var size = cc.director.getWinSize();
        var randX = cc.random0To1() * (size.width + 10) - size.width / 2;
        if (randX > 0) {
            randX -= 20;
        } else {
            randX += 20;
        }
        // 根据地平面位置和主角跳跃高度，随机得到一个星星的 y 坐标
        var randY = size.height / 2;
        cc.log("随机的怪物坐标：%f %f", randX, randY);
        // 返回星星坐标
        return cc.p(randX, randY);
    },
    setInputControl: function setInputControl() {
        var self = this;

        cc.eventManager.addListener({
            event: cc.EventListener.TOUCH_ONE_BY_ONE,
            onTouchBegan: self._onTouchBegan.bind(self)
        }, self);
    },
    _onTouchBegan: function _onTouchBegan() {

        return true;
    },
    // called every frame, uncomment this function to activate update callback
    update: function update(dt) {
        this.timeindex++;
        if (this.timeindex > 40) {
            this.timeindex = 0;
            var eid = parseInt(cc.random0To1() * 4);
            this.spawnZombie(eid);
        }
    },
    backGame: function backGame() {

        cc.director.loadScene('JiangShi');
    },
    goEnd: function goEnd() {

        this.gameover.active = true;
    }
});