require=(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({"Begin":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'cdfa0cxUnNB/o5O+Cz+BMcF', 'Begin');
// Begin.js

cc.Class({
    'extends': cc.Component,

    properties: {
        // foo: {
        //    default: null,
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    // use this for initialization
    onLoad: function onLoad() {},

    whichButton: function whichButton() {
        cc.director.loadScene('GameScene');
    },

    HelpButton: function HelpButton() {
        cc.director.loadScene('Help');
    }

});
// called every frame, uncomment this function to activate update callback
// update: function (dt) {

// },

cc._RFpop();
},{}],"ButtonScaler":[function(require,module,exports){
"use strict";
cc._RFpush(module, '655a3WZ/SFCoJqU2EC5Qbcy', 'ButtonScaler');
// ButtonScaler.js

cc.Class({
    'extends': cc.Component,

    properties: {
        pressedScale: 1,
        transDuration: 0
    },

    // use this for initialization
    onLoad: function onLoad() {
        var self = this;
        self.initScale = this.node.scale;
        self.button = self.getComponent(cc.Button);
        self.scaleDownAction = cc.scaleTo(self.transDuration, self.pressedScale);
        self.scaleUpAction = cc.scaleTo(self.transDuration, self.initScale);
        function onTouchDown(event) {
            this.stopAllActions();
            this.runAction(self.scaleDownAction);
        }
        function onTouchUp(event) {
            this.stopAllActions();
            this.runAction(self.scaleUpAction);
        }
        this.node.on('touchstart', onTouchDown, this.node);
        this.node.on('touchend', onTouchUp, this.node);
        this.node.on('touchcancel', onTouchUp, this.node);
    }
});

cc._RFpop();
},{}],"GameManager":[function(require,module,exports){
"use strict";
cc._RFpush(module, '45a8bWMVohA76UfTPRX+50+', 'GameManager');
// GameManager.js

cc.Class({
    'extends': cc.Component,

    properties: {
        //僵尸数组
        zbslist: {
            'default': [],
            type: [cc.Prefab]
        },
        //背景图片
        bglist: {
            'default': [],
            type: [cc.SpriteFrame]
        },
        //背景对象
        bg: {
            'default': null,
            type: cc.Sprite
        },
        gameover: {
            'default': null,
            type: cc.Node
        },
        bgAudio: {
            'default': null,
            url: cc.AudioClip
        },
        // score label 的引用
        scoreDisplay: {
            'default': null,
            type: cc.Label
        },
        // // score label 的引用
        scoreDisplay2: {
            'default': null,
            type: cc.Label
        }
    },

    // use this for initialization
    onLoad: function onLoad() {
        //随机背景
        var bgid = parseInt(cc.random0To1() * 3);
        cc.log("随机到的背景：%d", bgid);
        this.bg.spriteFrame = this.bglist[bgid];
        //定义怪物数组
        // this.zombies = [];

        this.gameover.active = false;
        this.timeindex = 0;
        this.score = 0;
        //声音
        cc.audioEngine.playEffect(this.bgAudio, true);
    },
    spawnZombie: function spawnZombie(type) {
        // 使用给定的模板在场景中生成一个新节点
        var newZombie = cc.instantiate(this.zbslist[type]);
        // 将新增的节点添加到 Canvas 节点下面
        this.node.addChild(newZombie);
        // newZombie.getComponent('Zombie').init(type);
        // 为星星设置一个随机位置
        newZombie.setPosition(this.getNewZombiePosition());
    },
    gainScore: function gainScore() {
        this.score += 1;

        //   // 更新 scoreDisplay Label 的文字
        this.scoreDisplay.string = 'Score:' + this.score.toString();
        this.scoreDisplay2.string = '' + this.score.toString();
    },

    getNewZombiePosition: function getZombiePosition() {

        var size = cc.director.getWinSize();
        var randX = cc.random0To1() * (size.width + 10) - size.width / 2;
        if (randX > 0) {
            randX -= 20;
        } else {
            randX += 20;
        }
        // 根据地平面位置和主角跳跃高度，随机得到一个星星的 y 坐标
        var randY = size.height / 2;
        cc.log("随机的怪物坐标：%f %f", randX, randY);
        // 返回星星坐标
        return cc.p(randX, randY);
    },
    setInputControl: function setInputControl() {
        var self = this;

        cc.eventManager.addListener({
            event: cc.EventListener.TOUCH_ONE_BY_ONE,
            onTouchBegan: self._onTouchBegan.bind(self)
        }, self);
    },
    _onTouchBegan: function _onTouchBegan() {

        return true;
    },
    // called every frame, uncomment this function to activate update callback
    update: function update(dt) {
        this.timeindex++;
        if (this.timeindex > 40) {
            this.timeindex = 0;
            var eid = parseInt(cc.random0To1() * 4);
            this.spawnZombie(eid);
        }
    },
    backGame: function backGame() {

        cc.director.loadScene('JiangShi');
    },
    goEnd: function goEnd() {

        this.gameover.active = true;
    }
});

cc._RFpop();
},{}],"GameOverButton":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'abaa9LE83NIGbLqPMRlJnyl', 'GameOverButton');
// GameOverButton.js

cc.Class({
    'extends': cc.Component,

    properties: {
        // foo: {
        //    default: null,
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    // use this for initialization
    onLoad: function onLoad() {},
    backhome: function backhome() {
        cc.director.resume();
        cc.director.loadScene('JiangShi');
    },
    backGame: function backGame() {
        cc.director.resume();
        cc.director.loadScene('GameScene');
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RFpop();
},{}],"GameSceneBack":[function(require,module,exports){
"use strict";
cc._RFpush(module, '4af9dR9C95Hz4smn9MNTuzr', 'GameSceneBack');
// GameSceneBack.js

cc.Class({
    "extends": cc.Component,

    properties: {
        // foo: {
        //    default: null,
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    // use this for initialization
    onLoad: function onLoad() {},
    GameSceneButton: function GameSceneButton() {
        cc.director.loadScene("JiangShi");
    }
});
// called every frame, uncomment this function to activate update callback
// update: function (dt) {

// },

cc._RFpop();
},{}],"HelpBackButton":[function(require,module,exports){
"use strict";
cc._RFpush(module, '2e682/piwRBzaB/wQUAdArg', 'HelpBackButton');
// HelpBackButton.js

cc.Class({
    'extends': cc.Component,

    properties: {
        // foo: {
        //    default: null,
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    // use this for initialization
    onLoad: function onLoad() {},

    back: function back() {
        cc.director.loadScene('JiangShi');
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RFpop();
},{}],"SpriteDown":[function(require,module,exports){
"use strict";
cc._RFpush(module, '09108IJqFRJ7qW9YWpDFb5J', 'SpriteDown');
// SpriteDown.js

cc.Class({
    'extends': cc.Component,

    properties: {
        speed: 0,
        type: 0,
        touchAudio: {
            'default': null,
            url: cc.AudioClip
        },
        endAudio: {
            'default': null,
            url: cc.AudioClip
        }
    },

    // use this for initialization
    onLoad: function onLoad() {
        this.isinstate = false;
        this.stateMaxindex = 0;
        this.stateindex = 0;
        this.dir = 2;

        this.size = cc.director.getWinSize();
        this.anim = this.getComponent(cc.Animation);
        // this.anim.play("zb1die");
        this.isdie = false;
        this.setInputControl();
    },
    // called every frame, uncomment this function to activate update callback
    update: function update(dt) {

        if (!this.isdie) {
            if (this.type == 3) {
                if (this.node.y + 50 > 300) {
                    this.getComponent(cc.Sprite).setVisible(false);
                } else if (this.node.y <= 300 || this.node.y <= 0) {
                    this.getComponent(cc.Sprite).setVisible(true);
                }
                this.node.y -= this.speed;
                //随机一个反向，随即一个时间，20帧随机一次，3个状态
                if (!this.isinstate) {
                    this.isinstate = true;
                    //随机方向
                    this.dir = parseInt(cc.random0To1() * 3);
                    this.stateMaxindex = parseInt(cc.random0To1() * 20 + 20);
                    this.stateindex = 0;
                }
                if (this.dir == 0) {
                    if (this.node.x - 2 < -this.size.width / 2 + 20) {
                        this.dir = 1;
                    } else {
                        this.node.x -= 2;
                    }
                } else if (this.dir == 1) {
                    if (this.node.x + 2 > this.size.width / 2 - 20) {
                        this.dir = 0;
                    } else {
                        this.node.x += 2;
                    }
                }
                this.stateindex++;
                if (this.stateindex > this.stateMaxindex) {
                    this.isinstate = false;
                }
            } else if (this.type == 2) {
                this.node.y -= this.speed;
            } else if (this.type == 0) {
                this.node.y -= this.speed;
            } else if (this.type == 1) {
                this.node.y -= this.speed;

                //随机一个反向，随即一个时间，20帧随机一次，3个状态
                if (!this.isinstate) {
                    this.isinstate = true;
                    //随机方向
                    this.dir = parseInt(cc.random0To1() * 3);
                    this.stateMaxindex = parseInt(cc.random0To1() * 20 + 20);
                    this.stateindex = 0;
                }
                if (this.dir == 0) {
                    if (this.node.x - 2 < -this.size.width / 2 + 20) {
                        this.dir = 1;
                    } else {
                        this.node.x -= 2;
                    }
                } else if (this.dir == 1) {
                    if (this.node.x + 2 > this.size.width / 2 - 20) {
                        this.dir = 0;
                    } else {
                        this.node.x += 2;
                    }
                }
                this.stateindex++;
                if (this.stateindex > this.stateMaxindex) {
                    this.isinstate = false;
                }
            }
            if (this.type == 2) {
                return;
            } else if (this.node.y < -this.size.height / 2 - 20) {
                cc.audioEngine.playEffect(this.endAudio, false);
                this.node.destroy();
                cc.director.pause();
                //this.node.parent.getComponent('GameManager').spawnZombie(0);
                this.node.parent.getComponent('GameManager').goEnd();
            }
        }
    },
    setInputControl: function setInputControl() {
        var self = this;

        cc.eventManager.addListener({
            event: cc.EventListener.TOUCH_ONE_BY_ONE,
            onTouchBegan: self._onTouchBegan.bind(self)
        }, self);
    },
    _onTouchBegan: function _onTouchBegan(touch, event) {
        var tpos = this.node.convertTouchToNodeSpace(touch);
        if (!cc.director.isPaused() && !this.isdie && cc.pDistance(cc.p(this.node.width / 2, this.node.height / 2), tpos) < 20) {
            this.godie();
            cc.audioEngine.playEffect(this.touchAudio, false);
            this.isdie = true;

            this.schedule(function () {
                if (this.type == 2) {
                    cc.audioEngine.playEffect(this.endAudio, false);
                    cc.director.pause();
                    this.node.destroy();
                    this.node.parent.getComponent('GameManager').goEnd();
                } else {
                    this.node.destroy();
                    this.node.parent.getComponent('GameManager').gainScore();
                }
            }, 1, 0.5, 0.5);
        }
        return true;
    },
    godie: function godie() {
        if (this.type == 0) {
            this.anim.play("Die");
        } else if (this.type == 1) {
            this.anim.play("TwoDie");
        } else if (this.type == 2) {
            this.anim.play("childDie");
        } else if (this.type == 3) {
            this.anim.play("action3Die");
        }
    }

});

cc._RFpop();
},{}]},{},["SpriteDown","HelpBackButton","GameManager","GameSceneBack","ButtonScaler","GameOverButton","Begin"])
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkU6L0NvY29zQ3JlYXRvci9yZXNvdXJjZXMvYXBwLmFzYXIvbm9kZV9tb2R1bGVzL2Jyb3dzZXItcGFjay9fcHJlbHVkZS5qcyIsImFzc2V0cy9CZWdpbi5qcyIsImFzc2V0cy9CdXR0b25TY2FsZXIuanMiLCJhc3NldHMvR2FtZU1hbmFnZXIuanMiLCJhc3NldHMvR2FtZU92ZXJCdXR0b24uanMiLCJhc3NldHMvR2FtZVNjZW5lQmFjay5qcyIsImFzc2V0cy9IZWxwQmFja0J1dHRvbi5qcyIsImFzc2V0cy9TcHJpdGVEb3duLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FDQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDcENBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ2pDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3pIQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNwQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDOUJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNoQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EiLCJmaWxlIjoiZ2VuZXJhdGVkLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXNDb250ZW50IjpbIihmdW5jdGlvbiBlKHQsbixyKXtmdW5jdGlvbiBzKG8sdSl7aWYoIW5bb10pe2lmKCF0W29dKXt2YXIgYT10eXBlb2YgcmVxdWlyZT09XCJmdW5jdGlvblwiJiZyZXF1aXJlO2lmKCF1JiZhKXJldHVybiBhKG8sITApO2lmKGkpcmV0dXJuIGkobywhMCk7dmFyIGY9bmV3IEVycm9yKFwiQ2Fubm90IGZpbmQgbW9kdWxlICdcIitvK1wiJ1wiKTt0aHJvdyBmLmNvZGU9XCJNT0RVTEVfTk9UX0ZPVU5EXCIsZn12YXIgbD1uW29dPXtleHBvcnRzOnt9fTt0W29dWzBdLmNhbGwobC5leHBvcnRzLGZ1bmN0aW9uKGUpe3ZhciBuPXRbb11bMV1bZV07cmV0dXJuIHMobj9uOmUpfSxsLGwuZXhwb3J0cyxlLHQsbixyKX1yZXR1cm4gbltvXS5leHBvcnRzfXZhciBpPXR5cGVvZiByZXF1aXJlPT1cImZ1bmN0aW9uXCImJnJlcXVpcmU7Zm9yKHZhciBvPTA7bzxyLmxlbmd0aDtvKyspcyhyW29dKTtyZXR1cm4gc30pIiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJ2NkZmEwY3hVbk5CL281TytDeitCTWNGJywgJ0JlZ2luJyk7XG4vLyBCZWdpbi5qc1xuXG5jYy5DbGFzcyh7XG4gICAgJ2V4dGVuZHMnOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIC8vIGZvbzoge1xuICAgICAgICAvLyAgICBkZWZhdWx0OiBudWxsLFxuICAgICAgICAvLyAgICB1cmw6IGNjLlRleHR1cmUyRCwgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHR5cGVvZiBkZWZhdWx0XG4gICAgICAgIC8vICAgIHNlcmlhbGl6YWJsZTogdHJ1ZSwgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxuICAgICAgICAvLyAgICB2aXNpYmxlOiB0cnVlLCAgICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgZGlzcGxheU5hbWU6ICdGb28nLCAvLyBvcHRpb25hbFxuICAgICAgICAvLyAgICByZWFkb25seTogZmFsc2UsICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIGZhbHNlXG4gICAgICAgIC8vIH0sXG4gICAgICAgIC8vIC4uLlxuICAgIH0sXG5cbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cbiAgICBvbkxvYWQ6IGZ1bmN0aW9uIG9uTG9hZCgpIHt9LFxuXG4gICAgd2hpY2hCdXR0b246IGZ1bmN0aW9uIHdoaWNoQnV0dG9uKCkge1xuICAgICAgICBjYy5kaXJlY3Rvci5sb2FkU2NlbmUoJ0dhbWVTY2VuZScpO1xuICAgIH0sXG5cbiAgICBIZWxwQnV0dG9uOiBmdW5jdGlvbiBIZWxwQnV0dG9uKCkge1xuICAgICAgICBjYy5kaXJlY3Rvci5sb2FkU2NlbmUoJ0hlbHAnKTtcbiAgICB9XG5cbn0pO1xuLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcbi8vIHVwZGF0ZTogZnVuY3Rpb24gKGR0KSB7XG5cbi8vIH0sXG5cbmNjLl9SRnBvcCgpOyIsIlwidXNlIHN0cmljdFwiO1xuY2MuX1JGcHVzaChtb2R1bGUsICc2NTVhM1daL1NGQ29KcVUyRUM1UWJjeScsICdCdXR0b25TY2FsZXInKTtcbi8vIEJ1dHRvblNjYWxlci5qc1xuXG5jYy5DbGFzcyh7XG4gICAgJ2V4dGVuZHMnOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIHByZXNzZWRTY2FsZTogMSxcbiAgICAgICAgdHJhbnNEdXJhdGlvbjogMFxuICAgIH0sXG5cbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cbiAgICBvbkxvYWQ6IGZ1bmN0aW9uIG9uTG9hZCgpIHtcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgICAgICBzZWxmLmluaXRTY2FsZSA9IHRoaXMubm9kZS5zY2FsZTtcbiAgICAgICAgc2VsZi5idXR0b24gPSBzZWxmLmdldENvbXBvbmVudChjYy5CdXR0b24pO1xuICAgICAgICBzZWxmLnNjYWxlRG93bkFjdGlvbiA9IGNjLnNjYWxlVG8oc2VsZi50cmFuc0R1cmF0aW9uLCBzZWxmLnByZXNzZWRTY2FsZSk7XG4gICAgICAgIHNlbGYuc2NhbGVVcEFjdGlvbiA9IGNjLnNjYWxlVG8oc2VsZi50cmFuc0R1cmF0aW9uLCBzZWxmLmluaXRTY2FsZSk7XG4gICAgICAgIGZ1bmN0aW9uIG9uVG91Y2hEb3duKGV2ZW50KSB7XG4gICAgICAgICAgICB0aGlzLnN0b3BBbGxBY3Rpb25zKCk7XG4gICAgICAgICAgICB0aGlzLnJ1bkFjdGlvbihzZWxmLnNjYWxlRG93bkFjdGlvbik7XG4gICAgICAgIH1cbiAgICAgICAgZnVuY3Rpb24gb25Ub3VjaFVwKGV2ZW50KSB7XG4gICAgICAgICAgICB0aGlzLnN0b3BBbGxBY3Rpb25zKCk7XG4gICAgICAgICAgICB0aGlzLnJ1bkFjdGlvbihzZWxmLnNjYWxlVXBBY3Rpb24pO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMubm9kZS5vbigndG91Y2hzdGFydCcsIG9uVG91Y2hEb3duLCB0aGlzLm5vZGUpO1xuICAgICAgICB0aGlzLm5vZGUub24oJ3RvdWNoZW5kJywgb25Ub3VjaFVwLCB0aGlzLm5vZGUpO1xuICAgICAgICB0aGlzLm5vZGUub24oJ3RvdWNoY2FuY2VsJywgb25Ub3VjaFVwLCB0aGlzLm5vZGUpO1xuICAgIH1cbn0pO1xuXG5jYy5fUkZwb3AoKTsiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnNDVhOGJXTVZvaEE3NlVmVFBSWCs1MCsnLCAnR2FtZU1hbmFnZXInKTtcbi8vIEdhbWVNYW5hZ2VyLmpzXG5cbmNjLkNsYXNzKHtcbiAgICAnZXh0ZW5kcyc6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgLy/lg7XlsLjmlbDnu4RcbiAgICAgICAgemJzbGlzdDoge1xuICAgICAgICAgICAgJ2RlZmF1bHQnOiBbXSxcbiAgICAgICAgICAgIHR5cGU6IFtjYy5QcmVmYWJdXG4gICAgICAgIH0sXG4gICAgICAgIC8v6IOM5pmv5Zu+54mHXG4gICAgICAgIGJnbGlzdDoge1xuICAgICAgICAgICAgJ2RlZmF1bHQnOiBbXSxcbiAgICAgICAgICAgIHR5cGU6IFtjYy5TcHJpdGVGcmFtZV1cbiAgICAgICAgfSxcbiAgICAgICAgLy/og4zmma/lr7nosaFcbiAgICAgICAgYmc6IHtcbiAgICAgICAgICAgICdkZWZhdWx0JzogbnVsbCxcbiAgICAgICAgICAgIHR5cGU6IGNjLlNwcml0ZVxuICAgICAgICB9LFxuICAgICAgICBnYW1lb3Zlcjoge1xuICAgICAgICAgICAgJ2RlZmF1bHQnOiBudWxsLFxuICAgICAgICAgICAgdHlwZTogY2MuTm9kZVxuICAgICAgICB9LFxuICAgICAgICBiZ0F1ZGlvOiB7XG4gICAgICAgICAgICAnZGVmYXVsdCc6IG51bGwsXG4gICAgICAgICAgICB1cmw6IGNjLkF1ZGlvQ2xpcFxuICAgICAgICB9LFxuICAgICAgICAvLyBzY29yZSBsYWJlbCDnmoTlvJXnlKhcbiAgICAgICAgc2NvcmVEaXNwbGF5OiB7XG4gICAgICAgICAgICAnZGVmYXVsdCc6IG51bGwsXG4gICAgICAgICAgICB0eXBlOiBjYy5MYWJlbFxuICAgICAgICB9LFxuICAgICAgICAvLyAvLyBzY29yZSBsYWJlbCDnmoTlvJXnlKhcbiAgICAgICAgc2NvcmVEaXNwbGF5Mjoge1xuICAgICAgICAgICAgJ2RlZmF1bHQnOiBudWxsLFxuICAgICAgICAgICAgdHlwZTogY2MuTGFiZWxcbiAgICAgICAgfVxuICAgIH0sXG5cbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cbiAgICBvbkxvYWQ6IGZ1bmN0aW9uIG9uTG9hZCgpIHtcbiAgICAgICAgLy/pmo/mnLrog4zmma9cbiAgICAgICAgdmFyIGJnaWQgPSBwYXJzZUludChjYy5yYW5kb20wVG8xKCkgKiAzKTtcbiAgICAgICAgY2MubG9nKFwi6ZqP5py65Yiw55qE6IOM5pmv77yaJWRcIiwgYmdpZCk7XG4gICAgICAgIHRoaXMuYmcuc3ByaXRlRnJhbWUgPSB0aGlzLmJnbGlzdFtiZ2lkXTtcbiAgICAgICAgLy/lrprkuYnmgKrnianmlbDnu4RcbiAgICAgICAgLy8gdGhpcy56b21iaWVzID0gW107XG5cbiAgICAgICAgdGhpcy5nYW1lb3Zlci5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgdGhpcy50aW1laW5kZXggPSAwO1xuICAgICAgICB0aGlzLnNjb3JlID0gMDtcbiAgICAgICAgLy/lo7Dpn7NcbiAgICAgICAgY2MuYXVkaW9FbmdpbmUucGxheUVmZmVjdCh0aGlzLmJnQXVkaW8sIHRydWUpO1xuICAgIH0sXG4gICAgc3Bhd25ab21iaWU6IGZ1bmN0aW9uIHNwYXduWm9tYmllKHR5cGUpIHtcbiAgICAgICAgLy8g5L2/55So57uZ5a6a55qE5qih5p2/5Zyo5Zy65pmv5Lit55Sf5oiQ5LiA5Liq5paw6IqC54K5XG4gICAgICAgIHZhciBuZXdab21iaWUgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLnpic2xpc3RbdHlwZV0pO1xuICAgICAgICAvLyDlsIbmlrDlop7nmoToioLngrnmt7vliqDliLAgQ2FudmFzIOiKgueCueS4i+mdolxuICAgICAgICB0aGlzLm5vZGUuYWRkQ2hpbGQobmV3Wm9tYmllKTtcbiAgICAgICAgLy8gbmV3Wm9tYmllLmdldENvbXBvbmVudCgnWm9tYmllJykuaW5pdCh0eXBlKTtcbiAgICAgICAgLy8g5Li65pif5pif6K6+572u5LiA5Liq6ZqP5py65L2N572uXG4gICAgICAgIG5ld1pvbWJpZS5zZXRQb3NpdGlvbih0aGlzLmdldE5ld1pvbWJpZVBvc2l0aW9uKCkpO1xuICAgIH0sXG4gICAgZ2FpblNjb3JlOiBmdW5jdGlvbiBnYWluU2NvcmUoKSB7XG4gICAgICAgIHRoaXMuc2NvcmUgKz0gMTtcblxuICAgICAgICAvLyAgIC8vIOabtOaWsCBzY29yZURpc3BsYXkgTGFiZWwg55qE5paH5a2XXG4gICAgICAgIHRoaXMuc2NvcmVEaXNwbGF5LnN0cmluZyA9ICdTY29yZTonICsgdGhpcy5zY29yZS50b1N0cmluZygpO1xuICAgICAgICB0aGlzLnNjb3JlRGlzcGxheTIuc3RyaW5nID0gJycgKyB0aGlzLnNjb3JlLnRvU3RyaW5nKCk7XG4gICAgfSxcblxuICAgIGdldE5ld1pvbWJpZVBvc2l0aW9uOiBmdW5jdGlvbiBnZXRab21iaWVQb3NpdGlvbigpIHtcblxuICAgICAgICB2YXIgc2l6ZSA9IGNjLmRpcmVjdG9yLmdldFdpblNpemUoKTtcbiAgICAgICAgdmFyIHJhbmRYID0gY2MucmFuZG9tMFRvMSgpICogKHNpemUud2lkdGggKyAxMCkgLSBzaXplLndpZHRoIC8gMjtcbiAgICAgICAgaWYgKHJhbmRYID4gMCkge1xuICAgICAgICAgICAgcmFuZFggLT0gMjA7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByYW5kWCArPSAyMDtcbiAgICAgICAgfVxuICAgICAgICAvLyDmoLnmja7lnLDlubPpnaLkvY3nva7lkozkuLvop5Lot7Pot4Ppq5jluqbvvIzpmo/mnLrlvpfliLDkuIDkuKrmmJ/mmJ/nmoQgeSDlnZDmoIdcbiAgICAgICAgdmFyIHJhbmRZID0gc2l6ZS5oZWlnaHQgLyAyO1xuICAgICAgICBjYy5sb2coXCLpmo/mnLrnmoTmgKrnianlnZDmoIfvvJolZiAlZlwiLCByYW5kWCwgcmFuZFkpO1xuICAgICAgICAvLyDov5Tlm57mmJ/mmJ/lnZDmoIdcbiAgICAgICAgcmV0dXJuIGNjLnAocmFuZFgsIHJhbmRZKTtcbiAgICB9LFxuICAgIHNldElucHV0Q29udHJvbDogZnVuY3Rpb24gc2V0SW5wdXRDb250cm9sKCkge1xuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XG5cbiAgICAgICAgY2MuZXZlbnRNYW5hZ2VyLmFkZExpc3RlbmVyKHtcbiAgICAgICAgICAgIGV2ZW50OiBjYy5FdmVudExpc3RlbmVyLlRPVUNIX09ORV9CWV9PTkUsXG4gICAgICAgICAgICBvblRvdWNoQmVnYW46IHNlbGYuX29uVG91Y2hCZWdhbi5iaW5kKHNlbGYpXG4gICAgICAgIH0sIHNlbGYpO1xuICAgIH0sXG4gICAgX29uVG91Y2hCZWdhbjogZnVuY3Rpb24gX29uVG91Y2hCZWdhbigpIHtcblxuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9LFxuICAgIC8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXG4gICAgdXBkYXRlOiBmdW5jdGlvbiB1cGRhdGUoZHQpIHtcbiAgICAgICAgdGhpcy50aW1laW5kZXgrKztcbiAgICAgICAgaWYgKHRoaXMudGltZWluZGV4ID4gNDApIHtcbiAgICAgICAgICAgIHRoaXMudGltZWluZGV4ID0gMDtcbiAgICAgICAgICAgIHZhciBlaWQgPSBwYXJzZUludChjYy5yYW5kb20wVG8xKCkgKiA0KTtcbiAgICAgICAgICAgIHRoaXMuc3Bhd25ab21iaWUoZWlkKTtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgYmFja0dhbWU6IGZ1bmN0aW9uIGJhY2tHYW1lKCkge1xuXG4gICAgICAgIGNjLmRpcmVjdG9yLmxvYWRTY2VuZSgnSmlhbmdTaGknKTtcbiAgICB9LFxuICAgIGdvRW5kOiBmdW5jdGlvbiBnb0VuZCgpIHtcblxuICAgICAgICB0aGlzLmdhbWVvdmVyLmFjdGl2ZSA9IHRydWU7XG4gICAgfVxufSk7XG5cbmNjLl9SRnBvcCgpOyIsIlwidXNlIHN0cmljdFwiO1xuY2MuX1JGcHVzaChtb2R1bGUsICdhYmFhOUxFODNOSUdiTHFQTVJsSm55bCcsICdHYW1lT3ZlckJ1dHRvbicpO1xuLy8gR2FtZU92ZXJCdXR0b24uanNcblxuY2MuQ2xhc3Moe1xuICAgICdleHRlbmRzJzogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICAvLyBmb286IHtcbiAgICAgICAgLy8gICAgZGVmYXVsdDogbnVsbCxcbiAgICAgICAgLy8gICAgdXJsOiBjYy5UZXh0dXJlMkQsICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0eXBlb2YgZGVmYXVsdFxuICAgICAgICAvLyAgICBzZXJpYWxpemFibGU6IHRydWUsIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgdmlzaWJsZTogdHJ1ZSwgICAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vICAgIGRpc3BsYXlOYW1lOiAnRm9vJywgLy8gb3B0aW9uYWxcbiAgICAgICAgLy8gICAgcmVhZG9ubHk6IGZhbHNlLCAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyBmYWxzZVxuICAgICAgICAvLyB9LFxuICAgICAgICAvLyAuLi5cbiAgICB9LFxuXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXG4gICAgb25Mb2FkOiBmdW5jdGlvbiBvbkxvYWQoKSB7fSxcbiAgICBiYWNraG9tZTogZnVuY3Rpb24gYmFja2hvbWUoKSB7XG4gICAgICAgIGNjLmRpcmVjdG9yLnJlc3VtZSgpO1xuICAgICAgICBjYy5kaXJlY3Rvci5sb2FkU2NlbmUoJ0ppYW5nU2hpJyk7XG4gICAgfSxcbiAgICBiYWNrR2FtZTogZnVuY3Rpb24gYmFja0dhbWUoKSB7XG4gICAgICAgIGNjLmRpcmVjdG9yLnJlc3VtZSgpO1xuICAgICAgICBjYy5kaXJlY3Rvci5sb2FkU2NlbmUoJ0dhbWVTY2VuZScpO1xuICAgIH1cblxuICAgIC8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXG4gICAgLy8gdXBkYXRlOiBmdW5jdGlvbiAoZHQpIHtcblxuICAgIC8vIH0sXG59KTtcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJzRhZjlkUjlDOTVIejRzbW45TU5UdXpyJywgJ0dhbWVTY2VuZUJhY2snKTtcbi8vIEdhbWVTY2VuZUJhY2suanNcblxuY2MuQ2xhc3Moe1xuICAgIFwiZXh0ZW5kc1wiOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIC8vIGZvbzoge1xuICAgICAgICAvLyAgICBkZWZhdWx0OiBudWxsLFxuICAgICAgICAvLyAgICB1cmw6IGNjLlRleHR1cmUyRCwgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHR5cGVvZiBkZWZhdWx0XG4gICAgICAgIC8vICAgIHNlcmlhbGl6YWJsZTogdHJ1ZSwgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxuICAgICAgICAvLyAgICB2aXNpYmxlOiB0cnVlLCAgICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgZGlzcGxheU5hbWU6ICdGb28nLCAvLyBvcHRpb25hbFxuICAgICAgICAvLyAgICByZWFkb25seTogZmFsc2UsICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIGZhbHNlXG4gICAgICAgIC8vIH0sXG4gICAgICAgIC8vIC4uLlxuICAgIH0sXG5cbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cbiAgICBvbkxvYWQ6IGZ1bmN0aW9uIG9uTG9hZCgpIHt9LFxuICAgIEdhbWVTY2VuZUJ1dHRvbjogZnVuY3Rpb24gR2FtZVNjZW5lQnV0dG9uKCkge1xuICAgICAgICBjYy5kaXJlY3Rvci5sb2FkU2NlbmUoXCJKaWFuZ1NoaVwiKTtcbiAgICB9XG59KTtcbi8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXG4vLyB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xuXG4vLyB9LFxuXG5jYy5fUkZwb3AoKTsiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnMmU2ODIvcGl3UkJ6YUIvd1FVQWRBcmcnLCAnSGVscEJhY2tCdXR0b24nKTtcbi8vIEhlbHBCYWNrQnV0dG9uLmpzXG5cbmNjLkNsYXNzKHtcbiAgICAnZXh0ZW5kcyc6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgLy8gZm9vOiB7XG4gICAgICAgIC8vICAgIGRlZmF1bHQ6IG51bGwsXG4gICAgICAgIC8vICAgIHVybDogY2MuVGV4dHVyZTJELCAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHlwZW9mIGRlZmF1bHRcbiAgICAgICAgLy8gICAgc2VyaWFsaXphYmxlOiB0cnVlLCAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vICAgIHZpc2libGU6IHRydWUsICAgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxuICAgICAgICAvLyAgICBkaXNwbGF5TmFtZTogJ0ZvbycsIC8vIG9wdGlvbmFsXG4gICAgICAgIC8vICAgIHJlYWRvbmx5OiBmYWxzZSwgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgZmFsc2VcbiAgICAgICAgLy8gfSxcbiAgICAgICAgLy8gLi4uXG4gICAgfSxcblxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxuICAgIG9uTG9hZDogZnVuY3Rpb24gb25Mb2FkKCkge30sXG5cbiAgICBiYWNrOiBmdW5jdGlvbiBiYWNrKCkge1xuICAgICAgICBjYy5kaXJlY3Rvci5sb2FkU2NlbmUoJ0ppYW5nU2hpJyk7XG4gICAgfVxuXG4gICAgLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcbiAgICAvLyB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xuXG4gICAgLy8gfSxcbn0pO1xuXG5jYy5fUkZwb3AoKTsiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnMDkxMDhJSnFGUko3cVc5WVdwREZiNUonLCAnU3ByaXRlRG93bicpO1xuLy8gU3ByaXRlRG93bi5qc1xuXG5jYy5DbGFzcyh7XG4gICAgJ2V4dGVuZHMnOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIHNwZWVkOiAwLFxuICAgICAgICB0eXBlOiAwLFxuICAgICAgICB0b3VjaEF1ZGlvOiB7XG4gICAgICAgICAgICAnZGVmYXVsdCc6IG51bGwsXG4gICAgICAgICAgICB1cmw6IGNjLkF1ZGlvQ2xpcFxuICAgICAgICB9LFxuICAgICAgICBlbmRBdWRpbzoge1xuICAgICAgICAgICAgJ2RlZmF1bHQnOiBudWxsLFxuICAgICAgICAgICAgdXJsOiBjYy5BdWRpb0NsaXBcbiAgICAgICAgfVxuICAgIH0sXG5cbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cbiAgICBvbkxvYWQ6IGZ1bmN0aW9uIG9uTG9hZCgpIHtcbiAgICAgICAgdGhpcy5pc2luc3RhdGUgPSBmYWxzZTtcbiAgICAgICAgdGhpcy5zdGF0ZU1heGluZGV4ID0gMDtcbiAgICAgICAgdGhpcy5zdGF0ZWluZGV4ID0gMDtcbiAgICAgICAgdGhpcy5kaXIgPSAyO1xuXG4gICAgICAgIHRoaXMuc2l6ZSA9IGNjLmRpcmVjdG9yLmdldFdpblNpemUoKTtcbiAgICAgICAgdGhpcy5hbmltID0gdGhpcy5nZXRDb21wb25lbnQoY2MuQW5pbWF0aW9uKTtcbiAgICAgICAgLy8gdGhpcy5hbmltLnBsYXkoXCJ6YjFkaWVcIik7XG4gICAgICAgIHRoaXMuaXNkaWUgPSBmYWxzZTtcbiAgICAgICAgdGhpcy5zZXRJbnB1dENvbnRyb2woKTtcbiAgICB9LFxuICAgIC8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXG4gICAgdXBkYXRlOiBmdW5jdGlvbiB1cGRhdGUoZHQpIHtcblxuICAgICAgICBpZiAoIXRoaXMuaXNkaWUpIHtcbiAgICAgICAgICAgIGlmICh0aGlzLnR5cGUgPT0gMykge1xuICAgICAgICAgICAgICAgIGlmICh0aGlzLm5vZGUueSArIDUwID4gMzAwKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuZ2V0Q29tcG9uZW50KGNjLlNwcml0ZSkuc2V0VmlzaWJsZShmYWxzZSk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIGlmICh0aGlzLm5vZGUueSA8PSAzMDAgfHwgdGhpcy5ub2RlLnkgPD0gMCkge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmdldENvbXBvbmVudChjYy5TcHJpdGUpLnNldFZpc2libGUodHJ1ZSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHRoaXMubm9kZS55IC09IHRoaXMuc3BlZWQ7XG4gICAgICAgICAgICAgICAgLy/pmo/mnLrkuIDkuKrlj43lkJHvvIzpmo/ljbPkuIDkuKrml7bpl7TvvIwyMOW4p+maj+acuuS4gOasoe+8jDPkuKrnirbmgIFcbiAgICAgICAgICAgICAgICBpZiAoIXRoaXMuaXNpbnN0YXRlKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuaXNpbnN0YXRlID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgLy/pmo/mnLrmlrnlkJFcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5kaXIgPSBwYXJzZUludChjYy5yYW5kb20wVG8xKCkgKiAzKTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5zdGF0ZU1heGluZGV4ID0gcGFyc2VJbnQoY2MucmFuZG9tMFRvMSgpICogMjAgKyAyMCk7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc3RhdGVpbmRleCA9IDA7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmRpciA9PSAwKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLm5vZGUueCAtIDIgPCAtdGhpcy5zaXplLndpZHRoIC8gMiArIDIwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmRpciA9IDE7XG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm5vZGUueCAtPSAyO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSBlbHNlIGlmICh0aGlzLmRpciA9PSAxKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLm5vZGUueCArIDIgPiB0aGlzLnNpemUud2lkdGggLyAyIC0gMjApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZGlyID0gMDtcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubm9kZS54ICs9IDI7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgdGhpcy5zdGF0ZWluZGV4Kys7XG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuc3RhdGVpbmRleCA+IHRoaXMuc3RhdGVNYXhpbmRleCkge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmlzaW5zdGF0ZSA9IGZhbHNlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gZWxzZSBpZiAodGhpcy50eXBlID09IDIpIHtcbiAgICAgICAgICAgICAgICB0aGlzLm5vZGUueSAtPSB0aGlzLnNwZWVkO1xuICAgICAgICAgICAgfSBlbHNlIGlmICh0aGlzLnR5cGUgPT0gMCkge1xuICAgICAgICAgICAgICAgIHRoaXMubm9kZS55IC09IHRoaXMuc3BlZWQ7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKHRoaXMudHlwZSA9PSAxKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5ub2RlLnkgLT0gdGhpcy5zcGVlZDtcblxuICAgICAgICAgICAgICAgIC8v6ZqP5py65LiA5Liq5Y+N5ZCR77yM6ZqP5Y2z5LiA5Liq5pe26Ze077yMMjDluKfpmo/mnLrkuIDmrKHvvIwz5Liq54q25oCBXG4gICAgICAgICAgICAgICAgaWYgKCF0aGlzLmlzaW5zdGF0ZSkge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmlzaW5zdGF0ZSA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgIC8v6ZqP5py65pa55ZCRXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuZGlyID0gcGFyc2VJbnQoY2MucmFuZG9tMFRvMSgpICogMyk7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc3RhdGVNYXhpbmRleCA9IHBhcnNlSW50KGNjLnJhbmRvbTBUbzEoKSAqIDIwICsgMjApO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnN0YXRlaW5kZXggPSAwO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAodGhpcy5kaXIgPT0gMCkge1xuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5ub2RlLnggLSAyIDwgLXRoaXMuc2l6ZS53aWR0aCAvIDIgKyAyMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5kaXIgPSAxO1xuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5ub2RlLnggLT0gMjtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAodGhpcy5kaXIgPT0gMSkge1xuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5ub2RlLnggKyAyID4gdGhpcy5zaXplLndpZHRoIC8gMiAtIDIwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmRpciA9IDA7XG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm5vZGUueCArPSAyO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHRoaXMuc3RhdGVpbmRleCsrO1xuICAgICAgICAgICAgICAgIGlmICh0aGlzLnN0YXRlaW5kZXggPiB0aGlzLnN0YXRlTWF4aW5kZXgpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5pc2luc3RhdGUgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAodGhpcy50eXBlID09IDIpIHtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9IGVsc2UgaWYgKHRoaXMubm9kZS55IDwgLXRoaXMuc2l6ZS5oZWlnaHQgLyAyIC0gMjApIHtcbiAgICAgICAgICAgICAgICBjYy5hdWRpb0VuZ2luZS5wbGF5RWZmZWN0KHRoaXMuZW5kQXVkaW8sIGZhbHNlKTtcbiAgICAgICAgICAgICAgICB0aGlzLm5vZGUuZGVzdHJveSgpO1xuICAgICAgICAgICAgICAgIGNjLmRpcmVjdG9yLnBhdXNlKCk7XG4gICAgICAgICAgICAgICAgLy90aGlzLm5vZGUucGFyZW50LmdldENvbXBvbmVudCgnR2FtZU1hbmFnZXInKS5zcGF3blpvbWJpZSgwKTtcbiAgICAgICAgICAgICAgICB0aGlzLm5vZGUucGFyZW50LmdldENvbXBvbmVudCgnR2FtZU1hbmFnZXInKS5nb0VuZCgpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfSxcbiAgICBzZXRJbnB1dENvbnRyb2w6IGZ1bmN0aW9uIHNldElucHV0Q29udHJvbCgpIHtcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xuXG4gICAgICAgIGNjLmV2ZW50TWFuYWdlci5hZGRMaXN0ZW5lcih7XG4gICAgICAgICAgICBldmVudDogY2MuRXZlbnRMaXN0ZW5lci5UT1VDSF9PTkVfQllfT05FLFxuICAgICAgICAgICAgb25Ub3VjaEJlZ2FuOiBzZWxmLl9vblRvdWNoQmVnYW4uYmluZChzZWxmKVxuICAgICAgICB9LCBzZWxmKTtcbiAgICB9LFxuICAgIF9vblRvdWNoQmVnYW46IGZ1bmN0aW9uIF9vblRvdWNoQmVnYW4odG91Y2gsIGV2ZW50KSB7XG4gICAgICAgIHZhciB0cG9zID0gdGhpcy5ub2RlLmNvbnZlcnRUb3VjaFRvTm9kZVNwYWNlKHRvdWNoKTtcbiAgICAgICAgaWYgKCFjYy5kaXJlY3Rvci5pc1BhdXNlZCgpICYmICF0aGlzLmlzZGllICYmIGNjLnBEaXN0YW5jZShjYy5wKHRoaXMubm9kZS53aWR0aCAvIDIsIHRoaXMubm9kZS5oZWlnaHQgLyAyKSwgdHBvcykgPCAyMCkge1xuICAgICAgICAgICAgdGhpcy5nb2RpZSgpO1xuICAgICAgICAgICAgY2MuYXVkaW9FbmdpbmUucGxheUVmZmVjdCh0aGlzLnRvdWNoQXVkaW8sIGZhbHNlKTtcbiAgICAgICAgICAgIHRoaXMuaXNkaWUgPSB0cnVlO1xuXG4gICAgICAgICAgICB0aGlzLnNjaGVkdWxlKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICBpZiAodGhpcy50eXBlID09IDIpIHtcbiAgICAgICAgICAgICAgICAgICAgY2MuYXVkaW9FbmdpbmUucGxheUVmZmVjdCh0aGlzLmVuZEF1ZGlvLCBmYWxzZSk7XG4gICAgICAgICAgICAgICAgICAgIGNjLmRpcmVjdG9yLnBhdXNlKCk7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMubm9kZS5kZXN0cm95KCk7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMubm9kZS5wYXJlbnQuZ2V0Q29tcG9uZW50KCdHYW1lTWFuYWdlcicpLmdvRW5kKCk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5ub2RlLmRlc3Ryb3koKTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5ub2RlLnBhcmVudC5nZXRDb21wb25lbnQoJ0dhbWVNYW5hZ2VyJykuZ2FpblNjb3JlKCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSwgMSwgMC41LCAwLjUpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH0sXG4gICAgZ29kaWU6IGZ1bmN0aW9uIGdvZGllKCkge1xuICAgICAgICBpZiAodGhpcy50eXBlID09IDApIHtcbiAgICAgICAgICAgIHRoaXMuYW5pbS5wbGF5KFwiRGllXCIpO1xuICAgICAgICB9IGVsc2UgaWYgKHRoaXMudHlwZSA9PSAxKSB7XG4gICAgICAgICAgICB0aGlzLmFuaW0ucGxheShcIlR3b0RpZVwiKTtcbiAgICAgICAgfSBlbHNlIGlmICh0aGlzLnR5cGUgPT0gMikge1xuICAgICAgICAgICAgdGhpcy5hbmltLnBsYXkoXCJjaGlsZERpZVwiKTtcbiAgICAgICAgfSBlbHNlIGlmICh0aGlzLnR5cGUgPT0gMykge1xuICAgICAgICAgICAgdGhpcy5hbmltLnBsYXkoXCJhY3Rpb24zRGllXCIpO1xuICAgICAgICB9XG4gICAgfVxuXG59KTtcblxuY2MuX1JGcG9wKCk7Il19
